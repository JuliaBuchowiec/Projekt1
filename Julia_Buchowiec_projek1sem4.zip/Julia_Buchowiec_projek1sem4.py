# -*- coding: utf-8 -*-
"""
Created on Mon Apr  1 08:27:28 2019

@author: Julia Buchowiec
"""

#--------------import bibliotek-------------
import tkinter as tk
import math
import matplotlib.pyplot as plt


#------------utworzenie okna dialogowego--------- 
window=tk.Tk()
window.title("Wyznaczenie punktu przecięcia dwóch odcinków:")
window.geometry('2000x540')



#------------wprowadzenie danych------------
def sprawdz(okno_rodzic,okno_rodzic1,okno_rodzic2, okno_rodzic3,okno_rodzic4, okno_rodzic5, okno_rodzic6,okno_rodzic7,pole1,pole2, pole3, pole4, pole5, pole6, pole7, pole8):
  okno=tk.Label(okno_rodzic)
  okno1=tk.Label(okno_rodzic1)
  okno2=tk.Label(okno_rodzic2)
  okno3=tk.Label(okno_rodzic3)
  okno4=tk.Label(okno_rodzic4)
  okno5=tk.Label(okno_rodzic5)
  okno6=tk.Label(okno_rodzic6)
  okno7=tk.Label(okno_rodzic7)
  XA=str(pole1.get()) #przechwytywanie z pól z pole1, pole2
  YA=str(pole2.get())
  XB=str(pole3.get())
  YB=str(pole4.get())
  XC=str(pole5.get())
  YC=str(pole6.get())
  XD=str(pole7.get())
  YD=str(pole8.get())
  a=XA.lstrip("-").replace(".","", 1).isdigit()
  A=YA.lstrip("-").replace(".","", 1).isdigit()
  b=XB.lstrip("-").replace(".","", 1).isdigit()
  B=YB.lstrip("-").replace(".","", 1).isdigit()
  c=XC.lstrip("-").replace(".","", 1).isdigit()
  C=YC.lstrip("-").replace(".","", 1).isdigit()
  d=XD.lstrip("-").replace(".","", 1).isdigit()
  D=YD.lstrip("-").replace(".","", 1).isdigit()
  if a==False:
      XA=str(pole1.get())
      if a==False:
          suma=str("Podano błędną wpółrzędną X punktu A, popraw wprowadzone dane")
  elif a==True:
       XA=float(XA)
       suma=str("Współrzędna X punktu A podana poprawnie")
       
  if A==False:
      YA=str(pole2.get())
      if A==False:
          suma1=str("Podano błędną wpółrzędną Y punktu A, popraw wprowadzone dane")
  elif A==True:
       YA=float(YA)
       suma1=str("Współrzędna Y punktu A podana poprawnie")
       
       
  if b==False:
      XB=str(pole3.get())
      if b==False:
          suma2=str("Podano błędną wpółrzędną X punktu B, popraw wprowadzone dane")
  elif b==True:
       XB=float(XB)
       suma2=str("Współrzędna X punktu B podana poprawnie")
       
  if B==False:
      YB=str(pole4.get())
      if B==False:
          suma3=str("Podano błędną wpółrzędną Y punktu B, popraw wprowadzone dane")
  elif B==True:
       YB=float(YB)
       suma3=str("Współrzędna Y punktu B podana poprawnie")
    
    
  if c==False:
      XC=str(pole5.get())
      if c==False:
          suma4=str("Podano błędną wpółrzędną X punktu C, popraw wprowadzone dane")
  elif c==True:
       XC=float(XC)
       suma4=str("Współrzędna X punktu C podana poprawnie")
       
  if C==False:
      YC=str(pole6.get())
      if C==False:
          suma5=str("Podano błędną wpółrzędną Y punktu C, popraw wprowadzone dane")
          
  elif C==True:
       YC=float(YC)
       suma5=str("Współrzędna Y punktu C podana poprawnie")
       
  if d==False:
      XD=str(pole7.get())
      if d==False:
          suma6=str("Podano błędną wpółrzędną X punktu D, popraw wprowadzone dane")
  elif d==True:
       XD=float(XD)
       suma6=str("Współrzędna X punktu D podana poprawnie")
       
  if D==False:
      YD=str(pole8.get())
      if D==False:
          suma7=str("Podano błędną wpółrzędną Y punktu D, popraw wprowadzone dane")
          
  elif D==True:
       YD=float(YD)
       suma7=str("Współrzędna Y punktu D podana poprawnie")

  tk.Label(okno, text=suma).pack() #organizuje widżety w blokach przed umieszczeniem ich w widgecie nadrzędnym
  tk.Label(okno1, text=suma1).pack()
  tk.Label(okno2, text=suma2).pack() 
  tk.Label(okno3, text=suma3).pack() 
  tk.Label(okno4, text=suma4).pack() 
  tk.Label(okno5, text=suma5).pack() 
  tk.Label(okno6, text=suma6).pack() 
  tk.Label(okno7, text=suma7).pack() 
  okno.grid(column=2, row=1) #pozycjonowanie
  okno1.grid(column=2, row=2)
  okno2.grid(column=2, row=3)
  okno3.grid(column=2, row=4)
  okno4.grid(column=2, row=5)
  okno5.grid(column=2, row=6)
  okno6.grid(column=2, row=7)
  okno7.grid(column=2, row=8)


def przeciecie(ok,okno_rodzic,okno_rodzic2,pole1,pole2,pole3,pole4,pole5,pole6,pole7,pole8):
  okn=tk.Label(ok)
  okno=tk.Label(okno_rodzic)
  okno1=tk.Label(okno_rodzic2)
  XA=float(pole1.get()) #przechwytywanie z pól z pole1, pole2
  YA=float(pole2.get())
  XB=float(pole3.get())
  YB=float(pole4.get())
  XC=float(pole5.get())
  YC=float(pole6.get())
  XD=float(pole7.get())
  YD=float(pole8.get())
  deltaXAC=XC-XA
  deltaYCD=YD-YD
  deltaYAC=YC-YA
  deltaXCD=XD-XC
  deltaXAB=XB-XA
  deltaYCD=YD-YC
  deltaYAB=YB-YA
  deltaXCD=XD-XC
 
  if ((deltaXAB*deltaYCD)-(deltaYAB*deltaXCD))==0:
      nie=str("Nie można przeprowadzić obliczeń, punkt przeciecia nie istnieje")
      nie1=str("Wprowadzone współrzędne spowodują dzielenie przez 0") 
      tk.Label(okn,text=nie).pack()
      okn.grid(column=2, row=9)
      tk.Label(okn,text=nie1).pack()
      okn.grid(column=2, row=10)
  else: 
      t1=((deltaXAC*deltaYCD)-(deltaYAC*deltaXCD))/((deltaXAB*deltaYCD)-(deltaYAB*deltaXCD))
      t2=((deltaXAC*deltaYAB)-(deltaYAC*deltaXAB))/((deltaXAB*deltaYCD)-(deltaYAB*deltaXCD))
      XP=XA+t1*deltaXAB
      xpp='{:.3f}'.format(XP)
      YP=YA+t1*deltaYAB
      ypp='{:.3f}'.format(YP)
      wsp=str("Współrzędne punktu przecięcia: ")+str("X: ")+str(xpp)+str("m  ")+str("Y: ")+str(ypp)+str("m")
      tk.Label(okno1, text=wsp, bg='lightgreen').pack()
      okno1.grid(column=2, row=11)
      if 0<=t1<=1 and 0<=t2<=1:
          wynik=str("Punkt leży na przecięciu obu odcinków")
          tk.Label(okno, text=wynik).pack()
          okno.grid(column=2, row=10) #pozycjonowanie
      else:
          wynik=str("Punkt leży na przedłużeniu")
          tk.Label(okno, text=wynik).pack()
          okno.grid(column=2, row=10) #pozycjonowanie
  


def az(okno_rodzic,okno_rodzic1,pole1,pole2,pole3, pole4, pole5, pole6, pole7, pole8):
  okno=tk.Label(okno_rodzic)
  okno1=tk.Label(okno_rodzic1)
  XA=float(pole1.get()) #przechwytywanie z pól z pole1, pole2
  YA=float(pole2.get())
  XB=float(pole3.get())
  YB=float(pole4.get())
  XC=float(pole5.get())
  YC=float(pole6.get())
  XD=float(pole7.get())
  YD=float(pole8.get())
  dX=XB-XA
  dY=YB-YA
  dX1=XD-XC
  dY1=YD-YC
  if dX>0 and dY>0:
     A=math.atan(dY/dX) #w radianach
     A_deg=math.degrees(A) #pierwsza cwiartka
     azymut=str('Azymut wynosi:  ')+str(float(A_deg))
  elif dY>0 and dX<0:
     A=math.atan(dY/dX)+math.pi 
     A_deg=math.degrees(A) #druga cwiartka
     azymut=str('Azymut wynosi:  ')+str(float(A_deg))
  elif dY<0 and dX<0:
     A=math.atan(dY/dX)+math.pi 
     A_deg=math.degrees(A) #trzecia cwiartka
     azymut=str('Azymut wynosi:  ')+str(float(A_deg))
  elif dY<0 and dX>0:
     A=math.atan(dY/dX)+2*math.pi 
     A_deg=math.degrees(A) #czwarta cwiartka
     azymut=str('Azymut wynosi:  ')+str(float(A_deg))
  elif dY>0 and dX==0:
     A=math.pi/2 
     A_deg=math.degrees(A) 
     azymut=str('Azymut wynosi:  ')+str(float(A_deg))
  elif dX< 0 and dY==0:                    
     A=math.pi                       
     A_deg=math.degrees(A)              
     azymut=str('Azymut wynosi:  ')+str(float(A_deg))
  elif dX==0 and dY < 0:                   
     A=math.pi+math.pi/2          
     A_deg=math.degrees(A)            
     azymut=str('Azymut wynosi:  ')+str(float(A_deg))
  elif dX> 0 and dY==0:                    
     A=0                           
     A_deg=math.degrees(A)              
     azymut=str('Azymut wynosi:  ')+str(float(A_deg))
  azi='{:.25s}'.format(azymut)+str("   ")+str("degrees")
  tk.Label(okno, text=azi).pack()
  okno.grid(column=1, row=14)
  if dX1>0 and dY1>0:
     A=math.atan(dY/dX) #w radianach
     A_deg=math.degrees(A) #pierwsza cwiartka
     azymut1=str('Azymut wynosi:  ')+str(float(A_deg))
  elif dY1>0 and dX1<0:
     A=math.atan(dY/dX)+math.pi 
     A_deg=math.degrees(A) #druga cwiartka
     azymut1=str('Azymut wynosi:  ')+str(float(A_deg))
  elif dY1<0 and dX1<0:
     A=math.atan(dY/dX)+math.pi 
     A_deg=math.degrees(A) #trzecia cwiartka
     azymut1=str('Azymut wynosi:  ')+str(float(A_deg))
  elif dY1<0 and dX1>0:
     A=math.atan(dY/dX)+2*math.pi 
     A_deg=math.degrees(A) #czwarta cwiartka
     azymut1=str('Azymut wynosi:  ')+str(float(A_deg))
  elif dY1>0 and dX1==0:
     A=math.pi/2 
     A_deg=math.degrees(A) 
     azymut1=str('Azymut wynosi:  ')+str(float(A_deg))
  elif dX1< 0 and dY1==0:                    
     A=math.pi                       
     A_deg=math.degrees(A)              
     azymut=str('Azymut wynosi:  ')+str(float(A_deg))
  elif dX1==0 and dY1< 0:                   
     A=math.pi+math.pi/2          
     A_deg=math.degrees(A)            
     azymut1=str('Azymut wynosi:  ')+str(float(A_deg))
  elif dX1> 0 and dY1==0:                    
     A=0                           
     A_deg=math.degrees(A)              
     azymut1=str('Azymut wynosi:  ')+str(float(A_deg))
  azi1='{:.25s}'.format(azymut1)+str("   ")+str("degrees")
  tk.Label(okno1, text=azi1).pack()
  okno1.grid(column=1, row=15)
    
def odl(okno_rodzic,okno_rodzic1, pole1, pole2, pole3, pole4, pole5, pole6, pole7, pole8):
  okno=tk.Label(okno_rodzic)
  okno1=tk.Label(okno_rodzic1)
  XA=float(pole1.get()) #przechwytywanie z pól z pole1, pole2
  YA=float(pole2.get())
  XB=float(pole3.get())
  YB=float(pole4.get())
  dX1=XB-XA
  dY1=YB-YA
  XC=float(pole5.get())
  YC=float(pole6.get())
  XD=float(pole7.get())
  YD=float(pole8.get())
  odl1=math.sqrt(dX1**2+dY1**2)
  od1='{:.3f}'.format(odl1)
  dX2=XD-XC
  dY2=YD-YC
  odl2=math.sqrt(dX2**2+dY2**2)
  od2='{:.3f}'.format(odl2)
  odll1=str("Dlugosc odcinka AB:  ")+str(od1)+str("m")
  odll2=str("Dlugosc odcinka CD:  ")+str(od2)+str("m")
  tk.Label(okno, text=odll1).pack()
  tk.Label(okno1, text=odll2).pack()
  okno.grid(column=2, row=14)
  okno1.grid(column=2, row=15)

def wykres(okno_rodzic, pole1, pole2, pole3, pole4, pole5, pole6, pole7, pole8, pole9, pole10):
    XA=float(pole1.get()) #przechwytywanie z pól z pole1, pole2
    YA=float(pole2.get())
    XB=float(pole3.get())
    YB=float(pole4.get())
    XC=float(pole5.get())
    YC=float(pole6.get())
    XD=float(pole7.get())
    YD=float(pole8.get())    
    kolor=str(pole9.get())
    kolor1=str(pole10.get())
    deltaXAC=XC-XA
    deltaYCD=YD-YD
    deltaYAC=YC-YA
    deltaXCD=XD-XC
    deltaXAB=XB-XA
    deltaYCD=YD-YC
    deltaYAB=YB-YA
    deltaXCD=XD-XC
    t1=((deltaXAC*deltaYCD)-(deltaYAC*deltaXCD))/((deltaXAB*deltaYCD)-(deltaYAB*deltaXCD))
    t2=((deltaXAC*deltaYAB)-(deltaYAC*deltaXAB))/((deltaXAB*deltaYCD)-(deltaYAB*deltaXCD))
    XP=XA+t1*deltaXAB
    YP=YA+t1*deltaYAB 
    if 0<=t1<=1 and 0<=t2<=1:
       print("Punkt na przecięciu")
    elif ((deltaXAB*deltaYCD)-(deltaYAB*deltaXCD))==0:
       print("")
    else:
        wykres1=plt.plot([XA,XP], [YA, YP], '--r')
        wykres1=plt.plot([XC,XP], [YC,YP], '--b')
    wykres1=plt.plot([XA, XB], [YA, YB], color=kolor, label="odcinek AB");
    wykres1=plt.plot([XC, XD], [YC, YD], color=kolor1, label="odcinek CD");
    wykres1=plt.scatter(XA,YA, color="orange", label="Punkt A  "+str(float(XA))+str("; ")+str(float(YA))) 
    wykres1=plt.scatter(XB,YB, color="pink", label="Puntk B  "+str(float(XB))+str("; ")+str(float(YB))) 
    wykres1=plt.scatter(XC,YC, color="black", label="Punkt C  "+str(float(XC))+str("; ")+str(float(YC))) 
    wykres1=plt.scatter(XD,YD, color="yellow", label="Punkt D  "+str(float(XD))+str("; ")+str(float(YD)))
    wykres1=plt.scatter(XP,YP, color="blue", label="Punkt P  "+str('{:.3f}'.format(XP))+str("; ")+str('{:.3f}'.format(YP)))
    wykres1=plt.xlabel("X")
    wykres1=plt.ylabel("Y")
    wykres1=plt.legend()
    wykres1=plt.title("Wizualizacja analizowanych punktów")
    wykres1=tk.Label(okno_rodzic)
    tk.Label(wykres1).pack()
    wykres1.grid(column=5, row=15) #pozycjonowanie


def polo(okno_rodzic, okno_rodzic1, pole1, pole2, pole3, pole4, pole5, pole6, pole7, pole8):
    okno=tk.Label(okno_rodzic)
    okno1=tk.Label(okno_rodzic1)
    XA=float(pole1.get()) #przechwytywanie z pól z pole1, pole2
    YA=float(pole2.get())
    XB=float(pole3.get())
    YB=float(pole4.get())
    XC=float(pole5.get())
    YC=float(pole6.get())
    XD=float(pole7.get())
    YD=float(pole8.get()) 
    wyz=XA*YB+XB*YC+XC*YA-XC*YB-XA*YC-XB*YA
    wyz1=XA*YB+XB*YD+XD*YA-XD*YB-XA*YD-XB*YA
    if wyz>0:
        polC=str("Punkt C leży po prawej stronie odcinka AB")
    elif wyz<0:
        polC=str("Punkt C leży po lewej stronie odcinka AB")
    else:
        polC=str("Punkty C,A i B są współliniowe")
    if wyz1>0:
        polD=str("Punkt D leży po prawej stronie odcinka AB")
    elif wyz1<0:
        polD=str("Punkt D leży po lewej stronie odcinka AB")
    else:
        polD=str("Punkty D,A i B są współliniowe")
    tk.Label(okno, text=polC).pack()
    tk.Label(okno1, text=polD).pack()
    okno.grid(column=0, row=14)
    okno1.grid(column=0, row=15)
    
def zapis(self, pole1, pole2, pole3, pole4, pole5, pole6, pole7, pole8):
    XA=float(pole1.get()) #przechwytywanie z pól z pole1, pole2
    YA=float(pole2.get())
    XB=float(pole3.get())
    YB=float(pole4.get())
    XC=float(pole5.get())
    YC=float(pole6.get())
    XD=float(pole7.get())
    YD=float(pole8.get())    
    deltaXAC=XC-XA
    deltaYCD=YD-YD
    deltaYAC=YC-YA
    deltaXCD=XD-XC
    deltaXAB=XB-XA
    deltaYCD=YD-YC
    deltaYAB=YB-YA
    deltaXCD=XD-XC
    t1=((deltaXAC*deltaYCD)-(deltaYAC*deltaXCD))/((deltaXAB*deltaYCD)-(deltaYAB*deltaXCD))
    XP=XA+t1*deltaXAB
    YP=YA+t1*deltaYAB 
    plik= open('projekt1_wspolrzedne.txt', "a");
    plik.write("\n| {:^16} | {:^16} | \n ".format("XP","YP"));
    plik.write("\n| {:^16.3f} | {:^16.3f} | \n ".format(XP,YP));


def clear(pole1, pole2, pole3, pole4, pole5, pole6, pole7, pole8):
    pole1.delete(0, 'end')
    pole2.delete(0, 'end')
    pole3.delete(0, 'end')
    pole4.delete(0, 'end')
    pole5.delete(0, 'end')
    pole6.delete(0, 'end')
    pole7.delete(0, 'end')
    pole8.delete(0, 'end')
    
#------------------Tworzenie przyciskow-------------    
b1=tk.Button(window, text="Sprawdź poprawność wprowadzonych współrzędnych ", bg="pink", command =lambda:sprawdz(window,window, window, window, window,window,window, window, txt,txt1,txt2,txt3,txt4,txt5,txt6,txt7))
b1.grid(column=1, row=9)
b2=tk.Button(window, text="Sprawdź gdzie leży punkt przecięcia i oblicz jego współrzędne: ", bg="pale violet red", command =lambda:przeciecie(window,window,window,txt,txt1,txt2,txt3,txt4,txt5,txt6,txt7))
b2.grid(column=1, row=10)
b5=tk.Button(window, text="Sprawdź położenie punktów C i D względem odcinków: ", bg="powderblue", command =lambda:polo(window,window,txt,txt1,txt2,txt3,txt4,txt5,txt6,txt7))
b5.grid(column=0, row=13)
b3=tk.Button(window, text="Oblicz azymut odcinka AB i azymut odcinka CD: ", bg="powderblue", command =lambda:az(window,window, txt,txt1,txt2,txt3,txt4,txt5,txt6,txt7))
b3.grid(column=1, row=13)
b3=tk.Button(window, text="Oblicz długość odcinka AB oraz dlugość odcinka CD: ", bg="powderblue", command =lambda:odl(window,window,txt,txt1,txt2,txt3,txt4,txt5,txt6,txt7))
b3.grid(column=2, row=13)
b4=tk.Button(window, text="Wyświetl wykres ilustrujący sytuację: ", bg="plum", command =lambda:wykres(window,txt,txt1,txt2,txt3,txt4,txt5,txt6,txt7,txt8,txt9))
b4.grid(column=5, row=4)
b6=tk.Checkbutton(window, text="Zapisz współrzędne punktu P do pliku", bg="pink", command =lambda:zapis(window,txt,txt1,txt2,txt3,txt4,txt5,txt6,txt7))
b6.grid(column=4, row=11)
b7=tk.Button(window, text="Wyczyść dane", bg="pink", command =lambda:clear(txt,txt1,txt2,txt3,txt4,txt5,txt6,txt7))
b7.grid(column=4, row=9)


#-------------------Pozycjonowanie etykietek-----------------
lb=tk.Label(window, text="Wyznaczenie punktu przecięcia dwóch odcinków: ",font="Corbel 12", bg="oldlace")
lb.grid(column=1, row=0) #pozycjonowanie
lbl=tk.Label(window, text="Wprowadź współrzędną X punktu A [m]:",font="Corbel 12", bg="beige")
lbl.grid(column=0, row=1) #pozycjonowanie
txt=tk.Entry(window,width=40) #tu podaje wartosci
txt.grid(column=1, row=1) #pozycjonowanie

lbl1=tk.Label(window, text="Wprowadź współrzędną Y punktu A [m]:",font="Corbel 12", bg="beige")
lbl1.grid(column=0, row=2)
txt1=tk.Entry(window,width=40) #tu podaje wartosci
txt1.grid(column=1, row=2)

lbl2=tk.Label(window, text="Wprowadź współrzędną X punktu B [m]:",font="Corbel 12", bg="beige")
lbl2.grid(column=0, row=3)
txt2=tk.Entry(window,width=40) #tu podaje wartosci
txt2.grid(column=1, row=3)

lbl3=tk.Label(window, text="Wprowadź współrzędną Y punktu B [m]:",font="Corbel 12", bg="beige")
lbl3.grid(column=0, row=4)
txt3=tk.Entry(window,width=40) #tu podaje wartosci
txt3.grid(column=1, row=4)

lbl4=tk.Label(window, text="Wprowadź współrzędną X punktu C [m]:",font="Corbel 12", bg="beige")
lbl4.grid(column=0, row=5)
txt4=tk.Entry(window,width=40) #tu podaje wartosci
txt4.grid(column=1, row=5)

lbl5=tk.Label(window, text="Wprowadź współrzędną Y punktu C [m]:",font="Corbel 12", bg="beige")
lbl5.grid(column=0, row=6)
txt5=tk.Entry(window,width=40) #tu podaje wartosci
txt5.grid(column=1, row=6)

lbl6=tk.Label(window, text="Wprowadź współrzędną X punktu D [m]:",font="Corbel 12", bg="beige")
lbl6.grid(column=0, row=7)
txt6=tk.Entry(window,width=40) #tu podaje wartosci
txt6.grid(column=1, row=7)

lbl7=tk.Label(window, text="Wprowadź współrzędną Y punktu D [m]:",font="Corbel 12", bg="beige")
lbl7.grid(column=0, row=8)
txt7=tk.Entry(window,width=40) #tu podaje wartosci
txt7.grid(column=1, row=8)

lbl8=tk.Label(window, text="Wprowadź nazwę koloru dla |AB| [eng]:",font="Corbel 12", bg="thistle")
lbl8.grid(column=4, row=2)
txt8=tk.Entry(window,width=40) #tu podaje wartosci
txt8.grid(column=5, row=2)

lbl9=tk.Label(window, text="Wprowadź nazwę koloru dla |CD| [eng]:",font="Corbel 12", bg="thistle")
lbl9.grid(column=4, row=3)
txt9=tk.Entry(window,width=40) #tu podaje wartosci
txt9.grid(column=5, row=3)

lbl10=tk.Label(window, text="Dodatkowe opcje programu", font="Corbel 12", bg="royal blue")
lbl10.grid(column=1, row=12)

lbl11=tk.Label(window, text="Projektowanie wykresu", font="Corbel 12", bg="orchid")
lbl11.grid(column=5, row=1)

lbl12=tk.Label(window, text="", font="Corbel 12", bg='whitesmoke')
lbl12.grid(column=1, row=11)

#---------------------------Legenda--------------------------
lbl13=tk.Label(window, text="Legenda kolorów", font="Corbel 12")
lbl13.grid(column=5, row=6)

lbl12=tk.Label(window, text="red", font="Corbel 12", bg='red')
lbl12.grid(column=5, row=7)
lbl12=tk.Label(window, text="blue", font="Corbel 12", bg='blue')
lbl12.grid(column=5, row=8)
lbl12=tk.Label(window, text="orange", font="Corbel 12", bg='orange')
lbl12.grid(column=5, row=9)
lbl12=tk.Label(window, text="green", font="Corbel 12", bg='green')
lbl12.grid(column=5, row=10)
lbl12=tk.Label(window, text="yellow", font="Corbel 12", bg='yellow')
lbl12.grid(column=5, row=11)
lbl12=tk.Label(window, text="pink", font="Corbel 12", bg='pink')
lbl12.grid(column=5, row=12)
lbl12=tk.Label(window, text="violet", font="Corbel 12", bg='violet')
lbl12.grid(column=5, row=13)
lbl12=tk.Label(window, text="cyan", font="Corbel 12", bg='cyan')
lbl12.grid(column=5, row=14)

#--------uruchmienie petli zdarzen---------
window.mainloop() 